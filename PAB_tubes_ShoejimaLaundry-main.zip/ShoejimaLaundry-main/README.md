# ShoejimaLaundry

Shoejima Laundry merupakan Sistem Informasi berbasis mobile yang dirancang menggunakan aplikasi Android Studio. Shoejima laundry merupakan aplikasi yang dibuat berdasarkan kemajuan teknologi yang bertujuan untuk mempermudah kegiatan masyarakat dalam proses pencucian sepatu. Di mana masyarakat yang dimaksud disini adalah mereka yang telah repot kerja seharian dan tidak memiliki waktu dan tenaga yang cukup untuk mencuci sepatu.

# Fitur-Fitur

- Pemesanan Laundry
- Details Pemesanan
- Pembayaran Laundry
- History Laundry

# Kontribusi Anggota

Pengembangan Front End - Muhammad Fadillah Akbar (21523177) - Fareesdzy Akhtarabillah Setiawan (21523140) - Dzikri Muhammad Jumadil (21523057)

Pengembangan Back End - Muhammad Fadillah Akbar (21523177) - Bima Panjalu Mukti (21523131) -
